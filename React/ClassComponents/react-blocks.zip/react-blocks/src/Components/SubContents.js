import React, {Component} from "react";
import styles from '../appStyles.module.css'


class SubContents extends Component{
    render(){
        return(
            <div className={styles.subContents}></div>
        )
    }
}

export default SubContents;